<?php
$host="localhost";
$username="root";
$password="";
$db_name="sms";
$conn=mysqli_connect($host,$username,$password,$db_name);
if($conn){
    echo "connection established";
}
else{
    echo "connection failed";
}
$id=$_GET['id'];
$sql="SELECT * FROM students WHERE id= $id";
$res=mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($res);
$name=$row['name'];
$address=$row['address'];
$city=$row['city'];
$gurname=$row['gurname'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table>
    <form action="./update.php" method="post">
<tr>
    <td>name</td>
    <td><input type="text" value="<?php echo $name?>" name="name"></td>
</tr>
<tr>
    <td>address</td>
    <td><input type="text" value="<?php echo $address?>" name="address"></td>
</tr>
<tr>
    <td>city</td>
    <td><input type="text" value="<?php echo $city?>" name="city"></td>
</tr>
<tr>
    <td>gurname</td>
    <td><input type="text" value="<?php echo $gurname?>" name="gurname"></td>
</tr>
<tr>
    <td>email</td>
    <td><input type="email" value="<?php echo $email?>" name="email"></td>
</tr>
<tr>
    <td>contact</td>
    <td><input type="text" value="<?php echo $contact?>" name="contact"></td>
</tr>
<input type="hidden" name="id" value="<?php echo $row['id'] ?>"> 
<tr>
    <td>pass</td>
    <td><input type="password" value="<?php echo $pass?>" name="pass"></td>
</tr>
<tr>
    <td>faculty_id</td>
    <td><input type="number" value="<?php echo $faculty_id?>" name="faculty_id"></td>
</tr>
<tr>
    <td>file_upload</td>
    <td><input type="file" value="<?php echo $file_upload?>" name="file_upload"></td>
</tr>
<tr>
    <td><input type="submit" name="sub" value="submit">
</tr>
</body>
</html>